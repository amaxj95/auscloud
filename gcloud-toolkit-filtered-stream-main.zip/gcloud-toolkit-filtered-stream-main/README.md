[Developer Guide: Twitter API Toolkit for Google Cloud - Filtered Stream](https://developer.twitter.com/en/docs/tutorials/developer-guide--twitter-api-toolkit-for-google-cloud1)
